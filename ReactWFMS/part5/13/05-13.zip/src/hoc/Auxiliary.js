const Auxiliary = (props) => {
  return props.children
}

export default Auxiliary