export const ADD = 'ADD'
export const SUB = 'SUB'
export const ADD_NUMBER = 'ADD_NUMBER'
export const ADD2 = 'ADD2'