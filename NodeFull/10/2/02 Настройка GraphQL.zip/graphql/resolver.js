module.exports = {
  test() {
    return 'Hello GraphQL!'
  }
}